package com.real.cu.bean;

public class Image {
	String img_code;
	int img_categori;
	String img_name;
	String img_board;
	public String getImg_code() {
		return img_code;
	}
	public void setImg_code(String img_code) {
		this.img_code = img_code;
	}
	public int getImg_categori() {
		return img_categori;
	}
	public void setImg_categori(int img_categori) {
		this.img_categori = img_categori;
	}
	public String getImg_name() {
		return img_name;
	}
	public void setImg_name(String img_name) {
		this.img_name = img_name;
	}
	public String getImg_board() {
		return img_board;
	}
	public void setImg_board(String img_board) {
		this.img_board = img_board;
	}
	
}
