package com.real.cu.bean;

public class Orderlist {
   String o_nrcode;
   int o_qty;
   String o_lhcode;
   int o_num;
   
   
   public int getO_num() {
      return o_num;
   }
   public void setO_num(int o_num) {
      this.o_num = o_num;
   }
   public String getO_nrcode() {
      return o_nrcode;
   }
   public void setO_nrcode(String o_nrcode) {
      this.o_nrcode = o_nrcode;
   }
   public int getO_qty() {
      return o_qty;
   }
   public void setO_qty(int o_qty) {
      this.o_qty = o_qty;
   }
   public String getO_lhcode() {
      return o_lhcode;
   }
   public void setO_lhcode(String o_lhcode) {
      this.o_lhcode = o_lhcode;
   }
   
}