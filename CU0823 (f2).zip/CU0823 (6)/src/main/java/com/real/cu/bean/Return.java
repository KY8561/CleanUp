package com.real.cu.bean;

import java.util.Date;

public class Return {
   String pr_code;
   String pr_pid;
   int pr_point;
   String pr_name;
   String pr_phone;
   String pr_banknum;
   String pr_bank;
   int pr_state;
   String pr_date;
   int pr_flag;
   
   public String getPr_phone() {
      return pr_phone;
   }
   public void setPr_phone(String pr_phone) {
      this.pr_phone = pr_phone;
   }
   public String getPr_code() {
      return pr_code;
   }
   public void setPr_code(String pr_code) {
      this.pr_code = pr_code;
   }
   public String getPr_pid() {
      return pr_pid;
   }
   public void setPr_pid(String pr_pid) {
      this.pr_pid = pr_pid;
   }
   public int getPr_point() {
      return pr_point;
   }
   public void setPr_point(int pr_point) {
      this.pr_point = pr_point;
   }
   public String getPr_name() {
      return pr_name;
   }
   public void setPr_name(String pr_name) {
      this.pr_name = pr_name;
   }
   public String getPr_banknum() {
      return pr_banknum;
   }
   public void setPr_banknum(String pr_banknum) {
      this.pr_banknum = pr_banknum;
   }
   public String getPr_bank() {
      return pr_bank;
   }
   public void setPr_bank(String pr_bank) {
      this.pr_bank = pr_bank;
   }
   public int getPr_state() {
      return pr_state;
   }
   public void setPr_state(int pr_state) {
      this.pr_state = pr_state;
   }
   public String getPr_date() {
      return pr_date;
   }
   public void setPr_date(String pr_date) {
      this.pr_date = pr_date;
   }
   public int getPr_flag() {
      return pr_flag;
   }
   public void setPr_flag(int pr_flag) {
      this.pr_flag = pr_flag;
   }
}