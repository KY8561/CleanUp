package com.real.cu.bean;


public class N_laundry {
   String nl_code;
   String nl_pid;
   String nl_name;
   String nl_address;
   String nl_phone;
   int nl_repair;
   String nl_open;
   String nl_close;
   String nl_content;
   int nl_permission;
   int nl_timelap;
   int nl_qty;
   String nl_date;
   public String getNl_date() {
      return nl_date;
   }
   public void setNl_date(String nl_date) {
      this.nl_date = nl_date;
   }
   public String getNl_code() {
      return nl_code;
   }
   public void setNl_code(String nl_code) {
      this.nl_code = nl_code;
   }
   public String getNl_pid() {
      return nl_pid;
   }
   public void setNl_pid(String nl_pid) {
      this.nl_pid = nl_pid;
   }
   public String getNl_name() {
      return nl_name;
   }
   public void setNl_name(String nl_name) {
      this.nl_name = nl_name;
   }
   public String getNl_address() {
      return nl_address;
   }
   public void setNl_address(String nl_address) {
      this.nl_address = nl_address;
   }
   public String getNl_phone() {
      return nl_phone;
   }
   public void setNl_phone(String nl_phone) {
      this.nl_phone = nl_phone;
   }
   public int getNl_repair() {
      return nl_repair;
   }
   public void setNl_repair(int nl_repair) {
      this.nl_repair = nl_repair;
   }
   public String getNl_open() {
      return nl_open;
   }
   public void setNl_open(String nl_open) {
      this.nl_open = nl_open;
   }
   public String getNl_close() {
      return nl_close;
   }
   public void setNl_close(String nl_close) {
      this.nl_close = nl_close;
   }
   public String getNl_content() {
      return nl_content;
   }
   public void setNl_content(String nl_content) {
      this.nl_content = nl_content;
   }
   public int getNl_permission() {
      return nl_permission;
   }
   public void setNl_permission(int nl_permission) {
      this.nl_permission = nl_permission;
   }
   public int getNl_timelap() {
      return nl_timelap;
   }
   public void setNl_timelap(int nl_timelap) {
      this.nl_timelap = nl_timelap;
   }
   public int getNl_qty() {
      return nl_qty;
   }
   public void setNl_qty(int nl_qty) {
      this.nl_qty = nl_qty;
   }
   
}