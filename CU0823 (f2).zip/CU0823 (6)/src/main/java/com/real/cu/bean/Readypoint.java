package com.real.cu.bean;

public class Readypoint {
	String rp_code;
	String rp_nrcode;
	String rp_downid;
	String rp_upid;
	int rp_point;
	int rp_state;
	public String getRp_code() {
		return rp_code;
	}
	public void setRp_code(String rp_code) {
		this.rp_code = rp_code;
	}
	public String getRp_nrcode() {
		return rp_nrcode;
	}
	public void setRp_nrcode(String rp_nrcode) {
		this.rp_nrcode = rp_nrcode;
	}
	public String getRp_downid() {
		return rp_downid;
	}
	public void setRp_downid(String rp_downid) {
		this.rp_downid = rp_downid;
	}
	public String getRp_upid() {
		return rp_upid;
	}
	public void setRp_upid(String rp_upid) {
		this.rp_upid = rp_upid;
	}
	public int getRp_point() {
		return rp_point;
	}
	public void setRp_point(int rp_point) {
		this.rp_point = rp_point;
	}
	public int getRp_state() {
		return rp_state;
	}
	public void setRp_state(int rp_state) {
		this.rp_state = rp_state;
	}
	
}
