package com.real.cu.bean;

import java.util.Date;

public class Mileage {
   String mg_code;
   String mg_pid;
   int mg_mileage;
   int mg_history;
   Date mg_date;
   int mg_updown;
   public String getMg_code() {
      return mg_code;
   }
   public void setMg_code(String mg_code) {
      this.mg_code = mg_code;
   }
   public String getMg_pid() {
      return mg_pid;
   }
   public void setMg_pid(String mg_pid) {
      this.mg_pid = mg_pid;
   }
   public int getMg_mileage() {
      return mg_mileage;
   }
   public void setMg_mileage(int mg_mileage) {
      this.mg_mileage = mg_mileage;
   }
   public int getMg_history() {
      return mg_history;
   }
   public void setMg_history(int mg_history) {
      this.mg_history = mg_history;
   }
   public Date getMg_date() {
      return mg_date;
   }
   public void setMg_date(Date mg_date) {
      this.mg_date = mg_date;
   }
   public int getMg_updown() {
      return mg_updown;
   }
   public void setMg_updown(int mg_updown) {
      this.mg_updown = mg_updown;
   }
   
}