package com.real.cu.bean;

import java.util.Date;

public class Coinreview {
	String cre_code;
	String cre_clcode;
	String cre_content;
	Date cre_date;
	int cre_star;
	String cre_pid;
	public String getCre_code() {
		return cre_code;
	}
	public void setCre_code(String cre_code) {
		this.cre_code = cre_code;
	}
	public String getCre_clcode() {
		return cre_clcode;
	}
	public void setCre_clcode(String cre_clcode) {
		this.cre_clcode = cre_clcode;
	}
	public String getCre_content() {
		return cre_content;
	}
	public void setCre_content(String cre_content) {
		this.cre_content = cre_content;
	}
	public Date getCre_date() {
		return cre_date;
	}
	public void setCre_date(Date cre_date) {
		this.cre_date = cre_date;
	}
	public int getCre_star() {
		return cre_star;
	}
	public void setCre_star(int cre_star) {
		this.cre_star = cre_star;
	}
	public String getCre_pid() {
		return cre_pid;
	}
	public void setCre_pid(String cre_pid) {
		this.cre_pid = cre_pid;
	}

}
