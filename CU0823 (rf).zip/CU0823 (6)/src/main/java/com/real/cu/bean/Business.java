package com.real.cu.bean;

public class Business {
	String b_pid;
	int b_lisence;
	public String getB_pid() {
		return b_pid;
	}
	public void setB_pid(String b_pid) {
		this.b_pid = b_pid;
	}
	public int getB_lisence() {
		return b_lisence;
	}
	public void setB_lisence(int b_lisence) {
		this.b_lisence = b_lisence;
	}
	
}
