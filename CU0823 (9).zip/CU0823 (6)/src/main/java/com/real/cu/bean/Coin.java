package com.real.cu.bean;

public class Coin {
   String cl_code;
   String cl_pid;
   String cl_name;
   String cl_address;
   String cl_phone;
   String cl_open;
   String cl_close;
   int cl_qty;
   String cl_content;
   int cl_permission;
   String cl_date;
   
   public String getCl_date() {
      return cl_date;
   }

   public void setCl_date(String cl_date) {
      this.cl_date = cl_date;
   }

   public String getCl_code() {
      return cl_code;
   }
   
   public String getCl_name() {
      return cl_name;
   }

   public void setCl_name(String cl_name) {
      this.cl_name = cl_name;
   }

   public int getCl_permission() {
      return cl_permission;
   }
   public void setCl_permission(int cl_permission) {
      this.cl_permission = cl_permission;
   }
   public void setCl_code(String cl_code) {
      this.cl_code = cl_code;
   }
   public String getCl_pid() {
      return cl_pid;
   }
   public void setCl_pid(String cl_pid) {
      this.cl_pid = cl_pid;
   }
   public String getCl_address() {
      return cl_address;
   }
   public void setCl_address(String cl_address) {
      this.cl_address = cl_address;
   }
   public String getCl_phone() {
      return cl_phone;
   }
   public void setCl_phone(String cl_phone) {
      this.cl_phone = cl_phone;
   }
   public String getCl_open() {
      return cl_open;
   }
   public void setCl_open(String cl_open) {
      this.cl_open = cl_open;
   }
   public String getCl_close() {
      return cl_close;
   }
   public void setCl_close(String cl_close) {
      this.cl_close = cl_close;
   }
   public int getCl_qty() {
      return cl_qty;
   }
   public void setCl_qty(int cl_qty) {
      this.cl_qty = cl_qty;
   }
   public String getCl_content() {
      return cl_content;
   }
   public void setCl_content(String cl_content) {
      this.cl_content = cl_content;
   }
   
}