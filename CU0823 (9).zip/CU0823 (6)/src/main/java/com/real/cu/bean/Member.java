package com.real.cu.bean;

public class Member {
	String m_pid;
	String m_address;
	String m_ggrade;
	public String getM_pid() {
		return m_pid;
	}
	public void setM_pid(String m_pid) {
		this.m_pid = m_pid;
	}
	public String getM_address() {
		return m_address;
	}
	public void setM_address(String m_address) {
		this.m_address = m_address;
	}
	public String getM_ggrade() {
		return m_ggrade;
	}
	public void setM_ggrade(String m_grade) {
		this.m_ggrade = m_grade;
	}

}
