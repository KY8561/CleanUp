package com.real.cu.bean;

import java.util.Date;

public class Review {
	String re_code;
	String re_nlcode;
	String re_content;
	Date re_date;
	int re_star;
	String re_pid;
	String re_nrcode;
	public String getRe_code() {
		return re_code;
	}
	public void setRe_code(String re_code) {
		this.re_code = re_code;
	}
	public String getRe_nlcode() {
		return re_nlcode;
	}
	public void setRe_nlcode(String re_nlcode) {
		this.re_nlcode = re_nlcode;
	}
	public String getRe_content() {
		return re_content;
	}
	public void setRe_content(String re_content) {
		this.re_content = re_content;
	}
	public Date getRe_date() {
		return re_date;
	}
	public void setRe_date(Date re_date) {
		this.re_date = re_date;
	}
	public int getRe_star() {
		return re_star;
	}
	public void setRe_star(int re_star) {
		this.re_star = re_star;
	}
	public String getRe_pid() {
		return re_pid;
	}
	public void setRe_pid(String re_pid) {
		this.re_pid = re_pid;
	}
	public String getRe_nrcode() {
		return re_nrcode;
	}
	public void setRe_nrcode(String re_nrcode) {
		this.re_nrcode = re_nrcode;
	}
}
