package com.real.cu.bean;

import java.util.Date;

public class Answer {
	String an_code;
	String an_rcode;
	String an_pid;
	String an_content;
	Date an_date;
	int an_state;
	public String getAn_code() {
		return an_code;
	}
	public void setAn_code(String an_code) {
		this.an_code = an_code;
	}
	public String getAn_rcode() {
		return an_rcode;
	}
	public void setAn_rcode(String an_rcode) {
		this.an_rcode = an_rcode;
	}
	public String getAn_pid() {
		return an_pid;
	}
	public void setAn_pid(String an_pid) {
		this.an_pid = an_pid;
	}
	public String getAn_content() {
		return an_content;
	}
	public void setAn_content(String an_content) {
		this.an_content = an_content;
	}
	public Date getAn_date() {
		return an_date;
	}
	public void setAn_date(Date an_date) {
		this.an_date = an_date;
	}
	public int getAn_state() {
		return an_state;
	}
	public void setAn_state(int an_state) {
		this.an_state = an_state;
	}
}
