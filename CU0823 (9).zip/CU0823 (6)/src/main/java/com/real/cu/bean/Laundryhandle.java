package com.real.cu.bean;

public class Laundryhandle {
	String lh_code;
	String lh_nlcode;
	String lh_laundry;
	int lh_payment;
	String lh_kind;
	
	public String getLh_kind() {
		return lh_kind;
	}
	public void setLh_kind(String lh_kind) {
		this.lh_kind = lh_kind;
	}
	public String getLh_code() {
		return lh_code;
	}
	public void setLh_code(String lh_code) {
		this.lh_code = lh_code;
	}
	public String getLh_nlcode() {
		return lh_nlcode;
	}
	public void setLh_nlcode(String lh_nlcode) {
		this.lh_nlcode = lh_nlcode;
	}
	public String getLh_laundry() {
		return lh_laundry;
	}
	public void setLh_laundry(String lh_laundry) {
		this.lh_laundry = lh_laundry;
	}
	public int getLh_payment() {
		return lh_payment;
	}
	public void setLh_payment(int lh_payment) {
		this.lh_payment = lh_payment;
	}
	
}
